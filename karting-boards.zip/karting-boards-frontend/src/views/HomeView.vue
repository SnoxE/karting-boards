<template>
  <KartingGrid />
</template>

<script>
import KartingGrid from '@/components/KartingGrid.vue'

export default {
  name: 'HomeView',
  components: {

    KartingGrid
  }
}
</script>

