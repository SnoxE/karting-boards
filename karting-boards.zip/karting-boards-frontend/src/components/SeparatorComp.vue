<template>
  <div class="h-20"></div>
</template>

<script>
export default {
  name: 'SeparatorComp'
}
</script>
