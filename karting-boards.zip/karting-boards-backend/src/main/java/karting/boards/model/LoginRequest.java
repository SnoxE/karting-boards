package karting.boards.model;

public record LoginRequest(String email, String password) {}
