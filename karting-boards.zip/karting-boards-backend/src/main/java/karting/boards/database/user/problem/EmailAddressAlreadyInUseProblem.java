package karting.boards.database.user.problem;

public class EmailAddressAlreadyInUseProblem {}
