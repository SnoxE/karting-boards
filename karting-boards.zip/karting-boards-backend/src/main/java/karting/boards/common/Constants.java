package karting.boards.common;

public class Constants {
    public static final String API_SECRET_KEY = "secretapikey";
    public static final long TOKEN_VALIDITY = 60 * 60 * 1000;


}
