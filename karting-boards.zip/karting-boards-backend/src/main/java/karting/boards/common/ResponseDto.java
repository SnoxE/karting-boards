package karting.boards.common;

public record ResponseDto(String message) {}
