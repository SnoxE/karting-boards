package karting.boards.common.resource;

public class ResourceException extends RuntimeException {

    public ResourceException(String message, Throwable cause) { super(message, cause); }
}
