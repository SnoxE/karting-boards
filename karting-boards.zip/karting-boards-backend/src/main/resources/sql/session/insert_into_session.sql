insert into session (id, track_id, date, time)
values (:id, :track_id, :date, :time);

