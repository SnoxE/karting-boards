SELECT
    COUNT(*)
FROM
    DRIVER
WHERE
    email = :email;

