INSERT INTO DRIVER (ID, FIRST_NAME, LAST_NAME, NICKNAME, SEX, EMAIL, PASSWORD, ROLE)
VALUES (:id, :first_name, :last_name, :nickname, :sex, :email, :password, :role);
