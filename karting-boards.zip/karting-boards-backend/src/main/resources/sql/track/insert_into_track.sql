insert into track (id, name, street, street_no, city, post_code, configuration, length)
values (:id, :name, :street, :street_no, :city, :post_code, :configuration, :length);

