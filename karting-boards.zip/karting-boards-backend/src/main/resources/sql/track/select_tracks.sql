SELECT
    t.id,
    t.name,
    t.street,
    t.street_no,
    t.city,
    t.post_code,
    t.configuration,
    t.length
FROM
    track AS t